/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tharishaperera.InventoryUI;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author THARISHA
 */
public class ProductList {
    private List<Product> product;

    public ProductList() {
        product = new ArrayList<>();
    }

}
