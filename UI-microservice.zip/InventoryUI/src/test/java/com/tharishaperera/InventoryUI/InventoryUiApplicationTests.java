package com.tharishaperera.InventoryUI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
